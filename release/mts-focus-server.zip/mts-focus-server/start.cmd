@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Install Node.js 24 or newer, then run start.cmd again.
  pause
  exit /b 1
)
node start.mjs
if errorlevel 1 pause
